package com.pjem.cidade.apicidade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCidadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
